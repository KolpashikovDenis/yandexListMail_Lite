Action()
{

	lr_start_transaction("OpenYandex");

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_add_cookie("ymai_iale=1; DOMAIN=mail.yandex.ru");

	web_add_cookie("yandexuid=1140716391554972219; DOMAIN=mail.yandex.ru");

	web_add_cookie("_ym_wasSynced=%7B%22time%22%3A1554972224802%2C%22params%22%3A%7B%22eu%22%3A0%7D%2C%22bkParams%22%3A%7B%7D%7D; DOMAIN=mail.yandex.ru");

	web_add_cookie("_ym_uid=1554972225315822506; DOMAIN=mail.yandex.ru");

	web_add_cookie("_ym_d=1554972225; DOMAIN=mail.yandex.ru");

	web_add_cookie("mda=0; DOMAIN=mail.yandex.ru");

	web_add_cookie("i=GoPTbuY2Btrz1fx1FY8NzSMns9+dp6oMu1x9o5YCdEbEghNtdtDUcEPAqLn5ktrjB86dXwFXHy2bVoAN2ZCH7GrGbKw=; DOMAIN=mail.yandex.ru");

	web_add_cookie("yp=1870332238.yrtsi.1554972238#1870332266.udn.cDpwZmxiVGVzdFRlc3Rvdg%3D%3D; DOMAIN=mail.yandex.ru");

	web_add_cookie("Session_id=3:1554972266.5.0.1554972266068:0-_5OwUKUK2CAJ_LcAQBIA:31.1|861056795.0.2|197600.259699.cTRmCWcups9manfGGVR2Sbcz48c; DOMAIN=mail.yandex.ru");

	web_add_cookie("sessionid2=3:1554972266.5.0.1554972266068:0-_5OwUKUK2CAJ_LcAQBIA:31.1|861056795.0.2|197600.388058.Bh1J4ksLql7Ks04kbFY_fHX1y3A; DOMAIN=mail.yandex.ru");

	web_add_cookie("L=flFEYWhFelZ+DlNpBnYEA1VkVXBkYFhRBRwUEz8OMCI8HAEiJBw=.1554972266.13832.312570.360ebf369ae5279d44d5325afa2d8ae1; DOMAIN=mail.yandex.ru");

	web_add_cookie("yandex_login=pflbTestTestov; DOMAIN=mail.yandex.ru");

	web_add_header("DNT", 
		"1");

	web_url("lite", 
		"URL=https://mail.yandex.ru/lite", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}